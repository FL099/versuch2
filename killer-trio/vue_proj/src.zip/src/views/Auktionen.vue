<template>
    <div class="px-4">
        <h1>Auktionen</h1>
        <div class="container">
            <h2>Laufende Auktionen</h2>
            <table class="table">
                <thead>
                    <tr>
                        <td>Bezeichnung</td>
                        <td>Menge</td>
                        <td>Enddatum</td>
                        <td></td>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Fanta</td>
                        <td>100</td>
                        <td>12.12.2021</td>
                        <td><button class="btn btn-success">bieten</button></td>
                    </tr>
                    <tr>
                        <td>Eistee</td>
                        <td>200</td>
                        <td>12.12.2021</td>
                        <td><button class="btn btn-success">bieten</button></td>
                    </tr>
                    <tr>
                        <td>Sprite</td>
                        <td>50</td>
                        <td>12.12.2021</td>
                        <td><button class="btn btn-success">bieten</button></td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="container">
            <h2>Vergangene Auktionen</h2>
            <table class="table">
                <thead>
                    <tr>
                        <td>Bezeichnung</td>
                        <td>Menge</td>
                        <td>Enddatum</td>
                        <td>Ergebnis</td>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Jägermeister</td>
                        <td>150</td>
                        <td>12.10.2021</td>
                        <td>Kolarik</td>
                    </tr>
                    <tr>
                        <td>Frucade</td>
                        <td>200</td>
                        <td>01.09.2021</td>
                        <td>Kolarik</td>
                    </tr>
                    <tr>
                        <td>Red Bull</td>
                        <td>50</td>
                        <td>29.01.2021</td>
                        <td>Red Bull</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</template>

<script>

export default {
  name: 'Auktionen',
};
</script>

<style scoped>
    h2{
        text-align: left;
    }
</style>
