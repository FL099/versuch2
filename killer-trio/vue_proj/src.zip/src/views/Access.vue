<template>
    <div class="container p-4">
        <ul class="nav nav-tabs">
        <li class="nav-item" v-on:click="toggle_vis('register')">
            <a class="nav-link active" id="register" aria-current="page" href="#">Register</a>
        </li>
        <li class="nav-item" v-on:click="toggle_vis('login')">
            <a class="nav-link" id="login" href="#">Login</a>
        </li>
        </ul>
        <div id="form">
            <Register
            class="content" id="registerform" />
            <Login
            class="content" id="loginform" style="display:none"/>
        </div>
    </div>
</template>

<script>
import Register from '../components/molecules/Register.vue';
import Login from '../components/molecules/Login.vue';

export default {
  name: 'Access',
  components: {
    Register,
    Login,
  },
  methods: {
    toggle_vis(item) {
      document.getElementsByClassName('active')[0].classList.remove('active');
      document.getElementById(item).classList.add('active');
      const contents = document.getElementsByClassName('content');
      document.getElementsByClassName('content')[0].style.display = 'none';
      contents[1].style.display = 'none';
      document.getElementById(`${item}form`).style.display = 'block';
    },
  },
};
</script>

<style>
</style>
