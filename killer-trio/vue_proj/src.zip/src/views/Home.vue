<template>
  <div class="container home">
    <h1 class="fw-bold">Willkommen zum Drink Market</h1>
    <p>Hi erstmal! Bei uns kann jeder seine Getränke reinstellen, so wie bei Ebay, nur in Cool.</p>
    <br>
    <CardList cardTitle1='Getränkename'/>
  </div>
</template>

<script>
// @ is an alias to /src
import CardList from '../components/molecules/CardList.vue';

export default {
  name: 'Home',
  components: {
    CardList,
  },
};
</script>

<style>

</style>
