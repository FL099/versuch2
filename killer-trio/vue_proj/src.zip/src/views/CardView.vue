<template>
    <div class="container" style="padding-top: 60px;">
        <div class="row">
            <div class="col-1"></div>
            <div class="col-4">
                <div>
                    <img src="#" width="70px">
                    <p>...</p>
                </div>
            </div>
            <div class="col-6" style="text-align: left;">
                <h1 >Getränkename</h1>
                <p>...</p>
                <button>bieten</button><span>&nbsp;</span>
                <button class="text-muted">Auktion erstellen</button>
            </div>
            <div class="col-1"></div>
        </div>
    </div>
</template>

<style scoped>
    button {
        background-color: white;
        border: none;
        border-left: 2px solid rgb(0, 0, 119);
        border-bottom: 2px solid rgb(0, 0, 119);
        border-bottom-left-radius: 4px;
        padding-bottom: 0;
        padding-top: 0;
        margin-right: 7px;
        padding-inline: 2px;
    }
    button:hover {
        background-color: white;
        border: none;
        border-left: 4px solid rgb(0, 155, 139);
        border-bottom: 4px solid rgb(0, 155, 139);
        border-bottom-left-radius: 6px;
    }
</style>
