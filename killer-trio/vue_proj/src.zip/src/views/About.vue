<template>
  <div class="container" id="about">
    <h1>About</h1>
    <h3>created by:</h3>
    <ul>
      <li><strong>Florian Sixtl</strong></li>
      <li><strong>Julia Koblmiller</strong></li>
      <li><strong>Luca Caspari</strong></li>
    </ul>

    <button type="button" class="btn btn-primary" data-bs-toggle="modal"
        data-bs-target="#exampleModal">
            Launch demo modal
    </button>
    <Modal :title='"It works!"' :text='"exampletest"' :btnText='"do it"' id="exampleModal"/>
  </div>
</template>

<script>

import Modal from '../components/Modal.vue';

export default {
  name: 'About',
  components: {
    Modal,
  },
};
</script>

<style scoped>
  #about{
    text-align: left;
  }

  h1{
    text-align: center;
  }

</style>
