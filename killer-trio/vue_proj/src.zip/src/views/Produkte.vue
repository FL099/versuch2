<template>
    <div class="px-4">
        <h1>Produkte</h1>
        <div>
            <ul>
                <li>...</li>
                <li>...</li>
                <li>...</li>
            </ul>
        </div>
    </div>
</template>

<script>

export default {
  name: 'Produkte',
};
</script>

<style scoped>
    h2{
        text-align: left;
    }
</style>
