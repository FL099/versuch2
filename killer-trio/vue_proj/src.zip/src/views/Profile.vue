<template>
  <div class="profile">
    <!--<h1>This is your Profile {{ Username }} !!</h1>-->
    <div>
      <div class="container mt-4">
        <div class="row" style="text-align: left;">
          <div class="col-6">
            <h2>Persönliche Daten</h2>
            <p><strong>Vorname</strong></p>
            <p>Max</p>
            <p><strong>Nachname</strong></p>
            <p>Mustermann</p>
            <p><strong>Geburtstag</strong></p>
            <p>01.12.2000</p>
          </div>
          <div class="col-6">
            <h2>Adressdaten</h2>
            <p><strong>Adresse</strong></p>
            <p>Minoritenplatz</p>
            <p><strong>Nummer</strong></p>
            <p>1</p>
            <p><strong>Postleitzahl</strong></p>
            <p>1010</p>
          </div>
        </div>        
      </div>
    </div>
  </div>
</template>


<script>
export default {
  name: 'Profile',
  props: ['Username']
};
</script>
