<template>
  <div class="py-3">
    <h2>Login - Anmelden</h2>
    <p>
      Mega nice dass du schon einen Account hast, nur noch anmelden und los
      geht's
    </p>
    <form class="m-5" style="text-align: left;">
      <TextInput
        :labelText="'Email'"
        :helptText="'this is your email'"
        :type="'email'"
        :value.sync="userMail"
      >
      </TextInput>

      <TextInput
        :labelText="'Dein Passwort'"
        :helpText="'Passwort sollte sicher und gemerkt sein'"
        :type="'password'"
        :value.sync="userPwd"
      >
      </TextInput>

      <div class="mb-3">
        <input type="checkbox" class="form-check-input me-2" id="Logincheck" />
        <label class="form-check-label" for="Logincheck"
          > Eingeloggt bleiben</label
        >
      </div>
      <button type="submit" v-on:click="loginUser" class="btn btn-primary">Login</button>
      <p class="text-primary">{{ responseMessage }}</p>
    </form>
  </div>
</template>

<script>
import axios from 'axios';
import TextInput from '../atoms/TextInput.vue';

export default {
  created() {
    // nix drinnen am anfang ;)
    this.userMail = "";
    this.userPwd = "";
    this.responseMessage = "";
  },
  data() {
    return {
      userMail: this.userMail,
      userPwd: this.userPwd,
      responseMessage: this.responseMessage,
    }
  },
  methods: {
    loginUser() {
      console.log("Trying to log in user with Email: " + this.userMail);
      axios.post("http://localhost:8081/auth", {
        email: this.userMail,
        password: this.userPwd,
      })
      .then((res) => {
        console.log("Der richtige Statuscode ist schonmal ein gutes Zeichen");

        console.log(res.data);
        if (res.data== "Login erfolgreich") {
          this.responseMessage = "Login erfolgreich";
        }
        else 
        {
          this.responseMessage = "Probier nochmal!";
        }
      })
      .catch((reason) => {
        if (reason.response.status === 400) {
          // handle 400
          this.responseMessage = "Email stimmt nicht";
        }
        else 
        {
          // error others
          this.responseMessage = "Ein unerwartetes Problem ist aufgetreten, bitte versuchen Sie es in einigen Minuten erneut.";
        }
      });
    }
  },
  name: 'Login',
  components: {
    TextInput,
  },
};
</script>
