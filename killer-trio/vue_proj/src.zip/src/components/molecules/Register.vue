<template>
  <div class="py-3">
    <h2>Registriere dich bei uns </h2>
    <p>Vollkommen gratis und unverbindlich</p>
    <form class="m-5" style="text-align: left;">
      <TextInput
        :labelText="'Vorname'"
        :helpText="'Darf auch dein Spitzname sein'"
        :provided_inputPlaceholder="'Max'"
        :type="'text'"
        :value.sync="firstName"
      >
      </TextInput>
      <TextInput
        :labelText="'Nachname'"
        :helpText="'Wie er im Buche steht'"
        :provided_inputPlaceholder="'Mustermann'"
        :type="'text'"
        :value.sync="lastName"
      >
      </TextInput>
      <TextInput
        :labelText="'Deine Email'"
        :helpText="'Wir passen gut auf sie auf!'"
        :type="'email'"
        :value.sync="userMail"
      >
      </TextInput>
      <TextInput
        :labelText="'Passwort erstellen'"
        :helpText="'Wird doppelt verschlüsselt, 1x bei dir und 1x bei uns'"
        :type="'password'"
        :value.sync="password"
      >
      </TextInput>
      <TextInput
        :labelText="'Password bestätigen'"
        :helpText="'Copy & Paste von oben ;)'"
        :type="'password'"
        :value.sync="password_confirm"
      >
      </TextInput>
      <div class="mb-3">
        <input type="checkbox" class="form-check-input me-2" id="check" />
        <label class="form-check-label" for="check"> Eingeloggt bleiben</label>
      </div>
      <div class="mb-3">
        <input type="checkbox" class="form-check-input me-2" id="agbCheck" required>
        <label class="form-check-label" for="agbCheck"><a href="#!">AGB</a> akzeptieren</label>
      </div>
      <button type="submit" v-on:click="registerUser" class="btn btn-primary">Registrieren</button>
      <p class="text-primary">{{ responseMessage }}</p>
    </form>
  </div>
</template>

<script>
import axios from 'axios';
import TextInput from '../atoms/TextInput.vue';

export default {
  name: 'Register',
  created() {
    this.firstName = "";
    this.lastName = "";
    this.userMail = "";
    this.userPwd = "";
    this.password_confirm = "";
    this.responseMessage = "";
  },
  data () {
    return {
      firstName: this.firstName,
      lastName: this.lastName,
      userMail: this.userMail,
      password: this.userPwd,
      password_confirm: this.password_confirm,
      responseMessage: this.responseMessage,
    }
  },
  components: {
    TextInput,
  },
  methods: {
    registerUser() {
      console.log("Registering User " + this.firstName + " " + this.lastName + " using (" + this.userMail + ") as E-Mail");
      axios.post("http://localhost:8081/user/", {
        firstName: this.firstName,
        lastName: this.lastName,
        email: this.userMail,
        password: this.userPwd,
      })
      .then((res) => {
        console.log("Seems to have worked!");
        this.responseMessage = "Das hat geklappt, wir leiten dich gleich weiter!";

        // expecting token from response
        console.log(res.data);
      }) 
      .catch((reason) => {
        if (reason.response.status === 400) {
          // handle 400
          this.responseMessage = "Es gibt einen Syntax Error, überprüfe deine Eingabe";
        }
        else 
        {
          // error others
          this.responseMessage = "Ein unerwartetes Problem ist aufgetreten, bitte versuchen Sie es in einigen Minuten erneut.";
        }
      })
    }
  }
};
</script>
