<template>
  <!--TODO: mit dem for... implementieren-->
  <div class="row">
    <div class="col-sm-4">
      <OfferCard
      :cardTitle="cardTitle1"
      :image_url="'bacardi.jpg'"/>
    </div>
    <div class="col-sm-4">
      <OfferCard :cardTitle="cardTitle1" />
    </div>
    <div class="col-sm-4">
      <OfferCard :cardTitle="cardTitle1" />
    </div>
  </div>
</template>

<script>
import OfferCard from './OfferCard.vue';

export default {
  name: 'CardList',
  components: {
    OfferCard,
  },
  props: ['cardTitle1'],
};
</script>

<style>
</style>
