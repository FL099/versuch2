<template>
  <div class="rounded shadow">
    <div class="">
      <div class="p-2">
        <img
          class="img-fluid rounded-start"
          src="../../assets/drinks.png"
          :alt="ui_cardTitle"
        />
      </div>
      <div class="">
        <div class="card-body">
          <h5 class="card-title">{{ ui_cardTitle }}</h5>
          <router-link to="/item" class="btn btn-primary">
            Angebot machen</router-link>
          <p class="card-text text-muted">{{ ui_cardDescription }}</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'OfferCard',
  data() {
    return {
      ui_cardTitle: this.cardTitle,
      ui_image_url: this.image_url,
      ui_cardDescription: this.cardDescription,
    };
  },
  props: ['cardTitle', 'image_url', 'cardDescription'],
  // der folgende code wird bei erstellung des components ausgeführt
  created() {
    // default image nur wenn eines übergeben wird überschreiben
    if (this.image_url !== undefined) {
      this.ui_image_url = this.image_url;
    }
    this.ui_image_url = `../../assets/${this.image_url}`; 
    // dasselbe für die beschreibung
    if (this.cardDescription !== undefined) {
      this.ui_cardDescription = this.cardDescription;
    }
  },
};
</script>
