<template>
  <nav class="bg-dark shadow mb-3" id="nav">
    <div class="d-flex flex-row justify-content-center align-items-center flex-wrap">
      <div class="">
        <router-link to="/" class="nav-link">
          <img
            src="DRINKMARKET.png"
            alt="Drink Market"
            width="200"
            class="d-inline-block align-text-top px-4 py-2"
          />
        </router-link>
      </div>
      <div class="d-flex align-items-center" id="navbarText">
        <router-link to="/access" class="nav-link"
          >Anmelden</router-link
        >
        |
        <router-link to="/auktionen" class="nav-link">Auktionen</router-link> |
        <router-link to="/produkte" class="nav-link">Produkte</router-link> |
        <router-link to="/profile" class="nav-link">Profil</router-link>
      </div>
    </div>
  </nav>
</template>

<script>
export default {
  name: 'Navbar',
};
</script>

<style scoped>
.nav-link {
  color: #fff !important;
}
#nav a.router-link-exact-active {
  color: #0d6efd;
}

#nav {
  padding: 5px;
}
</style>
